/*******************************************************************\
 *                                                                 *
 *                        DESLIZADOR LINEAL UTN                    *
 *                                                                 *
 *   Archivo:      main.cpp                                        *
 *   Autor:        Ernesto Palacios <meacatronica.mid@gmail.com>   *
 *   Version:      v2.0                                            *
 *   Dependencias: setup.h, setup.cpp                              *
 *   Descripci�n:  Este es el archivo principal para el microcon-  *
 *                 trolador mbed para la comunicaci�n  y  control  *
 *                 del deslizador                                  *
 *   Fecha:        Ibarra, 05 de junio de 2012                     *
 *                                                                 *
 *******************************************************************/
 
#include "mbed.h"
#include "setup.h"
#include "EthernetNetIf.h"
#include "HTTPServer.h"
#include "RPCFunction.h"
#include "RPCVariable.h"

//  Entradas Salidas 

Serial          pc( USBTX, USBRX ); //Comunicacion Serial directa al computador
Serial          RS_232(p9, p10);    //Comunicacion Serial para MAX232
I2C             encoder(p28, p27);  //Comunicacion I2C para los encoders

DigitalOut      pin_son( p7 );       // SON
DigitalOut      pin_dir( p26 );     //  SIGN+
InterruptIn     pin_alm( p8 );     //   ALM 
AnalogOut       aout( p18 );      //    VOUT

DigitalIn       isHTTP( p15 );   // Modo Ethernet/Serial
DigitalIn       isFast( p16 );   // Serial Alta velocidad/Baja Velocidad
DigitalIn       isPC  ( p17 );   // Salida a compuador o MAX232

DigitalOut      led_verde( p21 ); // Led verde del conector Ethernet
DigitalOut      led_rojo(  p22 ); // Led naranja del conector Ethernet

//  Objetos Ethernet

EthernetNetIf eth;  
HTTPServer svr;
LocalFileSystem fs("local");


//  Anadir funciones al Protocolo RPC:
//
//  estas son las funciones de acceso de la libreria HTTP_ASM sobre
//  el Protocolo RPC
RPCFunction SetFQ  (&setPTO_eth,  "PTO");
RPCFunction SetAOUT(&setAout_eth, "AOUT");
RPCFunction SetDIR (&setDir_eth,  "DIR");
RPCFunction SetSON (&setSON_eth,  "SON");
RPCFunction SetANG (&setANG_eth,  "ANG"); 
RPCFunction SetSpd (&setSPD_eth,  "VAN"); 
RPCFunction ReadSpd(&getENC_eth,  "VLC");


int main() {
    
//***************    Configura Red Ethernet     **************************************************//
    if( isHTTP )   
    {

        // A�ade clases base al protocolo RPC
        Base::add_rpc_class<AnalogIn>();
        Base::add_rpc_class<AnalogOut>();
        Base::add_rpc_class<DigitalIn>();
        Base::add_rpc_class<DigitalOut>();
        Base::add_rpc_class<DigitalInOut>();
        Base::add_rpc_class<PwmOut>();
        Base::add_rpc_class<Timer>();
        Base::add_rpc_class<BusOut>();
        Base::add_rpc_class<BusIn>();
        Base::add_rpc_class<BusInOut>();
        Base::add_rpc_class<Serial>();
        
        // Configura conexi�n Ethernet
        printf("Configurando...\n");
        EthernetErr ethErr = eth.setup();
        if(ethErr)
        {
            printf("Error %d en la configuracion.\n", ethErr);
            return -1;
        }
        printf("Setup OK\n");
                                   
        FSHandler::mount("/local", "/files"); //Monta /local en /files que es el directorio web
        FSHandler::mount("/local", "/");      //Mount /local en / que es el directorio raiz
  
        //Handles para la comunicacion
        svr.addHandler<SimpleHandler>("/hello");
        svr.addHandler<RPCHandler>("/rpc");
        svr.addHandler<FSHandler>("/files");
        svr.addHandler<FSHandler>("/"); 
        
        svr.bind(80);   // Puerto de comunicacion.
                       
        printf("Listo para comunicacion...\n");
   
        // Para probar la correcta configuracion acceder a mbed.htm
        // http://a.b.c.d/mbed.htm or http://a.b.c.d/files/mbed.htm
   
    }


//***************    Configura Comunicacion Serial     **************************************************//
    
    else  // Caso Contrario Anadir modo Serial
    {
        if( isPC )                      // Utiliza el Puerto Virtual Incluido.
        {
            pc.attach( &ISR_Serial );
            
            if( isFast )                     //Configurar Serial a alta velocidad
                pc.baud( 115200 );
        }
        else                          // Utiiliza el puerto serial hacia MAX232
        {
            RS_232.attach( &ISR_Serial );
            if( isFast )                     //Configurar Serial a alta velocidad
                RS_232.baud( 115200 );
        }
    }
    
//*******************************************************************************************************//
    
    
    // Ajustes iniciales del Driver
    setTimer2();    // Configurar PTO
    pin_son = 0;   // Servo Apagado por defecto
    aout = 0.5;   // Voltaje de salida 0V por defecto( +-10V! )
    
    
    // Atar las alarmas a las interrupciones
    
    pin_alm.fall( &ISR_Alarm ); // Entrada de la alarma
    
    while(1) 
    {
        if( isHTTP )
            Net::poll();  // Revisa la red solo si la coneccion es HTTP
    }
}

