//This file has been auto-generated, please do not modify here.
#ifndef __ETHERNETNETIF_CONFIG_H
#define NET_TELIT_STACK 0
#define NET_GPRS 0
#define NET_PPP 0
#define NET_ZG2100 0
#define TARGET_LPC1768 1
#define NET_GPRS_MODULE 0
#define NET_ETH 1
#define NET_USB_SERIAL 0
#define NET_CFG_H 1
#define NET_USB 0
#define NET_LWIP_STACK 1
#endif
