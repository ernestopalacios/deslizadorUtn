#undef NOLCD



#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>

#ifndef NOLCD
#  include <stdio.h>
#  include "i2cLcd.h"
#endif

#include "twi.h"



// Timer2 Clock Select and Output Compare value

#define TIMER2_TARGET_RATE 1000UL  // target rate in microseconds

#define TIMER2_MAX_COUNT    256UL

#if \
     ( ( TIMER2_MAX_COUNT * 1000UL *    1UL ) / ( F_CPU / 1000UL ) ) > \
     TIMER2_TARGET_RATE
#  define TIMER2_PRESCALER 1
#  define TIMER2_CS        ( 0 << CS02 ) | ( 0 << CS01 ) | ( 1 << CS00 )
#elif \
     ( ( TIMER2_MAX_COUNT * 1000UL *    8UL ) / ( F_CPU / 1000UL ) ) > \
     TIMER2_TARGET_RATE
#  define TIMER2_PRESCALER 8
#  define TIMER2_CS        ( 0 << CS02 ) | ( 1 << CS01 ) | ( 0 << CS00 )
#elif \
     ( ( TIMER2_MAX_COUNT * 1000UL *   32UL ) / ( F_CPU / 1000UL ) ) > \
     TIMER2_TARGET_RATE
#  define TIMER2_PRESCALER 32
#  define TIMER2_CS        ( 0 << CS02 ) | ( 1 << CS01 ) | ( 1 << CS00 )
#elif \
     ( ( TIMER2_MAX_COUNT * 1000UL *  64UL ) / ( F_CPU / 1000UL ) ) > \
     TIMER2_TARGET_RATE
#  define TIMER2_PRESCALER 64
#  define TIMER2_CS        ( 1 << CS02 ) | ( 0 << CS01 ) | ( 0 << CS00 )
#elif \
     ( ( TIMER2_MAX_COUNT * 1000UL * 128UL ) / ( F_CPU / 1000UL ) ) > \
     TIMER2_TARGET_RATE
#  define TIMER2_PRESCALER 128
#  define TIMER2_CS        ( 1 << CS02 ) | ( 0 << CS01 ) | ( 1 << CS00 )
#elif \
     ( ( TIMER2_MAX_COUNT * 1000UL * 256UL ) / ( F_CPU / 1000UL ) ) > \
     TIMER2_TARGET_RATE
#  define TIMER2_PRESCALER 256
#  define TIMER2_CS        ( 1 << CS02 ) | ( 1 << CS01 ) | ( 0 << CS00 )
#elif \
     ( ( TIMER2_MAX_COUNT * 1000UL * 1024UL ) / ( F_CPU / 1000UL ) ) > \
     TIMER2_TARGET_RATE
#  define TIMER2_PRESCALER 1024
#  define TIMER2_CS        ( 1 << CS02 ) | ( 1 << CS01 ) | ( 1 << CS00 )
#else
#  error TIMER2_TARGET_RATE not attainable
#endif

#define TIMER2_OUTPUT_COMPARE \
     ( TIMER2_TARGET_RATE * ( F_CPU / 100UL ) ) / \
     ( TIMER2_PRESCALER * 10000UL )



// TWI Slave defines

#define TWI_SLA 0x10  // Slave Address



// global data

static volatile uint8_t timerIntCount;



/********************************************************************************

                 Timer/Counter2 Compare Match Interrupt Handler

********************************************************************************/

ISR( TIMER2_COMPA_vect )
{

#ifndef NOLCD
  i2c_lcd_dec_timeout( );  // decrement TWI time-out counter
#endif

  twiDecTo( );  // decrement TWI time-out counter

  if ( timerIntCount != 0 ) timerIntCount--;

} // end ISR( TIMER2_COMP_vect )



/*******************************************************************************

                                      main

*******************************************************************************/

int
main(
  void
)
{



#ifndef NOLCD

  uint8_t i;

  char    dispValue[ 4 ];

#endif

  uint8_t rc, txData[ 2 ], rxData[ 3 ];



  // initialize TWI

  twiInit( 10 );



  // initialize Timer/Counter2

#ifndef OCR2A

  OCR2 = TIMER2_OUTPUT_COMPARE - 1;
                           // select CTC mode (WGM21..WGM20 = 10) and Clock Select
  TCCR2 = ( 1 << WGM21 ) | ( 0 << WGM20 ) | TIMER2_CS;
  TIMSK |= ( 1 << OCIE2 );  // enable Timer/Counter2 Output Compare Match interrupt

#else

  OCR2A = TIMER2_OUTPUT_COMPARE - 1;

  TCCR2A = ( 1 << WGM21 ) | ( 0 << WGM20 );
  TCCR2B = ( 0 << WGM22 ) | TIMER2_CS;

  TIMSK2 |= ( 1 << OCIE2A);  // enable Timer/Counter2 Output Compare Match A interrupt

#endif



  // set Global Interrupt Enable

  sei( );



#ifndef NOLCD



  // delay to allow I2C LCD to boot up and initialize

  for ( i = 0; i < 5; i++ )
  {
    timerIntCount = 200;
    while( timerIntCount != 0 );
  } // end for



  // initialize LCD interface

  i2c_lcd_init( 10, LCD_DISP_OFF );



  // turn display on, no cursor

  i2c_lcd_command( ( 1 << LCD_ON ) | ( 1 << LCD_ON_DISPLAY ) );



  // display something

  i2c_lcd_clrscr( );

  i2c_lcd_puts_p( PSTR( "Hello World!" ) );

  i2c_lcd_gotoxy( 0, 1 );



#endif // ifndef NOLCD



  memset( rxData, 0, sizeof( rxData ) );



  // write one data byte to slave

  txData[ 0 ] = 0x55;

  rc = twiWrite( TWI_SLA, txData, 1 );

  if ( rc != 0 )
  {
#ifndef NOLCD
    i2c_lcd_puts_p( PSTR( "twiWrite rc=" ) );
    sprintf( dispValue, "%02u", rc );
    i2c_lcd_puts( dispValue );
#endif
    return rc;
  } // end if



  // read one data byte from slave

  rc = twiRead( TWI_SLA, rxData, 1 );

  if ( rc != 0 )
  {
#ifndef NOLCD
    i2c_lcd_puts_p( PSTR( "twiRead rc=" ) );
    sprintf( dispValue, "%02u", rc );
    i2c_lcd_puts( dispValue );
#endif
    return rc;
  } // end if



  // write two data bytes to slave

  txData[ 0 ] = 0xAA;
  txData[ 1 ] = 0x12;

  rc = twiWrite( TWI_SLA, txData, 2 );

  if ( rc != 0 )
  {
#ifndef NOLCD
    i2c_lcd_puts_p( PSTR( "twiWrite rc=" ) );
    sprintf( dispValue, "%02u", rc );
    i2c_lcd_puts( dispValue );
#endif
    return rc;
  } // end if



  // read two data bytes from slave

  rc = twiRead( TWI_SLA, rxData + 1, 2 );

  if ( rc != 0 )
  {
#ifndef NOLCD
    i2c_lcd_puts_p( PSTR( "twiRead rc=" ) );
    sprintf( dispValue, "%02u", rc );
    i2c_lcd_puts( dispValue );
#endif
    return rc;
  } // end if



#ifndef NOLCD

  // display Rx data

  i2c_lcd_puts_p( PSTR( "read:" ) );

  for ( i = 0; i < sizeof( rxData ); i++ )
  {
    sprintf( dispValue, " %02X", rxData[ i ] );
    i2c_lcd_puts( dispValue );
  } // end for

#endif // ifndef NOLCD



  for ( ; ; );



  return 0;



} // end main
